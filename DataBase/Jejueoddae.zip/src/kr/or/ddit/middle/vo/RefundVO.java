package kr.or.ddit.middle.vo;
//환불 VO
public class RefundVO {
	
	private String rf_code;
	private String pay_no;
	private String rf_date;
	
	public String getRf_code() {
		return rf_code;
	}
	public void setRf_code(String rf_code) {
		this.rf_code = rf_code;
	}
	public String getPay_no() {
		return pay_no;
	}
	public void setPay_no(String pay_no) {
		this.pay_no = pay_no;
	}
	public String getRf_date() {
		return rf_date;
	}
	public void setRf_date(String rf_date) {
		this.rf_date = rf_date;
	}
	

}
