package kr.or.ddit.middle.vo;

public class MileageVO {

	private String mil_code;
	private String mem_id;
	private int mil_resamount;
	private int mil_useamount;

	public String getMil_code() {
		return mil_code;
	}

	public void setMil_code(String mil_code) {
		this.mil_code = mil_code;
	}

	public String getMem_id() {
		return mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

	public int getMil_resamount() {
		return mil_resamount;
	}

	public void setMil_resamount(int mil_resamount) {
		this.mil_resamount = mil_resamount;
	}

	public int getMil_useamount() {
		return mil_useamount;
	}

	public void setMil_useamount(int mil_useamount) {
		this.mil_useamount = mil_useamount;
	}

}
