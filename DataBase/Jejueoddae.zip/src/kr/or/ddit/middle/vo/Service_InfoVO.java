package kr.or.ddit.middle.vo;

public class Service_InfoVO {

	private String si_code;
	private String si_name;

	public Service_InfoVO() {
	}

	public String getSi_code() {
		return si_code;
	}

	public void setSi_code(String si_code) {
		this.si_code = si_code;
	}

	public String getSi_name() {
		return si_name;
	}

	public void setSi_name(String si_name) {
		this.si_name = si_name;
	}

}
