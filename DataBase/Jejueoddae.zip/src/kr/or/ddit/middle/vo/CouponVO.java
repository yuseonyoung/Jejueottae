package kr.or.ddit.middle.vo;

public class CouponVO {

	private String co_code;
	private String co_name;
	private int co_rate;

	public CouponVO() {
	}

	public String getCo_code() {
		return co_code;
	}

	public void setCo_code(String co_code) {
		this.co_code = co_code;
	}

	public String getCo_name() {
		return co_name;
	}

	public void setCo_name(String co_name) {
		this.co_name = co_name;
	}

	public int getCo_rate() {
		return co_rate;
	}

	public void setCo_rate(int co_rate) {
		this.co_rate = co_rate;
	}

	

}
