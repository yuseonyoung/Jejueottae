package kr.or.ddit.middle.vo;

//숙박서비스VO
public class Service_ListVO {
	private String a_code;
	private String si_code;

	public String getA_code() {
		return a_code;
	}

	public void setA_code(String a_code) {
		this.a_code = a_code;
	}

	public String getSi_code() {
		return si_code;
	}

	public void setSi_code(String si_code) {
		this.si_code = si_code;
	}

}
