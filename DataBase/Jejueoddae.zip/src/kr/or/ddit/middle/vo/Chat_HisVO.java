package kr.or.ddit.middle.vo;

public class Chat_HisVO {

	private String gb_code;
	private String mem_id;
	private String ch_filename;

	public String getGb_code() {
		return gb_code;
	}

	public void setGb_code(String gb_code) {
		this.gb_code = gb_code;
	}

	public String getCh_filename() {
		return ch_filename;
	}

	public void setCh_filename(String ch_filename) {
		this.ch_filename = ch_filename;
	}

	public String getMem_id() {
		return mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

}
