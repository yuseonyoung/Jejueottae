package kr.or.ddit.middle.vo;
//리뷰 VO
public class ReviewVO {
	private String rev_code;
	private String res_code;
	private String rev_date;
	private int rev_score;
	private String rev_title;
	private String rev_content;
	
	public String getRev_code() {
		return rev_code;
	}
	public void setRev_code(String rev_code) {
		this.rev_code = rev_code;
	}
	public String getRes_code() {
		return res_code;
	}
	public void setRes_code(String res_code) {
		this.res_code = res_code;
	}
	public String getRev_date() {
		return rev_date;
	}
	public void setRev_date(String rev_date) {
		this.rev_date = rev_date;
	}
	public int getRev_score() {
		return rev_score;
	}
	public void setRev_score(int rev_score) {
		this.rev_score = rev_score;
	}
	public String getRev_title() {
		return rev_title;
	}
	public void setRev_title(String rev_title) {
		this.rev_title = rev_title;
	}
	public String getRev_content() {
		return rev_content;
	}
	public void setRev_content(String rev_content) {
		this.rev_content = rev_content;
	}
	
	

}
