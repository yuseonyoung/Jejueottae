package kr.or.ddit.middle.vo;

public class Cp_HavingVO {

	private String co_code;
	private String mem_id;
	private int cp_use;

	public Cp_HavingVO() {
	}

	public String getCo_code() {
		return co_code;
	}

	public void setCo_code(String co_code) {
		this.co_code = co_code;
	}

	public String getMem_id() {
		return mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

	public int getCh_use() {
		return cp_use;
	}

	public void setCh_use(int ch_use) {
		this.cp_use = ch_use;
	}

	
}
