package kr.or.ddit.middle.vo;

public class His_MileageVO {

	
	private String mil_code;
	private String mem_id;
	private String mil_date;
	private String mil_savehis;
	private String mil_usehis;
	
	public String getMil_code() {
		return mil_code;
	}
	public void setMil_code(String mil_code) {
		this.mil_code = mil_code;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getMil_date() {
		return mil_date;
	}
	public void setMil_date(String mil_date) {
		this.mil_date = mil_date;
	}
	public String getMil_savehis() {
		return mil_savehis;
	}
	public void setMil_savehis(String mil_savehis) {
		this.mil_savehis = mil_savehis;
	}
	public String getMil_usehis() {
		return mil_usehis;
	}
	public void setMil_usehis(String mil_usehis) {
		this.mil_usehis = mil_usehis;
	}
	
	
	

}
