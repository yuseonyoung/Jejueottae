package kr.or.ddit.middle.vo;

public class GroupBuyingVO {

	private String gb_code;
	private String gb_title;
	private String gb_content;
	private String gb_date;
	private int gb_inven;
	private String mem_id;
	
	public String getGb_code() {
		return gb_code;
	}
	public void setGb_code(String gb_code) {
		this.gb_code = gb_code;
	}
	public String getGb_title() {
		return gb_title;
	}
	public void setGb_title(String gb_title) {
		this.gb_title = gb_title;
	}
	public String getGb_content() {
		return gb_content;
	}
	public void setGb_content(String gb_content) {
		this.gb_content = gb_content;
	}
	public String getGb_date() {
		return gb_date;
	}
	public void setGb_date(String gb_date) {
		this.gb_date = gb_date;
	}
	public int getGb_inven() {
		return gb_inven;
	}
	public void setGb_inven(int gb_inven) {
		this.gb_inven = gb_inven;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

	

}
