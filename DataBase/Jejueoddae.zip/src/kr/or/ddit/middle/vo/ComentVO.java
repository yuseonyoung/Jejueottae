package kr.or.ddit.middle.vo;

public class ComentVO {

	private String co_code;
	private String co_content;
	private String bo_code;
	
	public String getCo_code() {
		return co_code;
	}
	public void setCo_code(String co_code) {
		this.co_code = co_code;
	}
	public String getCo_content() {
		return co_content;
	}
	public void setCo_content(String co_content) {
		this.co_content = co_content;
	}
	public String getBo_code() {
		return bo_code;
	}
	public void setBo_code(String bo_code) {
		this.bo_code = bo_code;
	}

	

	
}
