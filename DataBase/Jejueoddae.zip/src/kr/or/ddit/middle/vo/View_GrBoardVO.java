package kr.or.ddit.middle.vo;

public class View_GrBoardVO {

	private String gb_code;
	private String gb_title;
	private String gb_content;
	private int gb_inven;
	private String gb_date;

	private String mem_id;
	private String mem_name;
	private String mem_code;
	private String mem_photo;

	public View_GrBoardVO() {
	}

	public String getGb_code() {
		return gb_code;
	}

	public void setGb_code(String gb_code) {
		this.gb_code = gb_code;
	}

	public String getGb_title() {
		return gb_title;
	}

	public void setGb_title(String gb_title) {
		this.gb_title = gb_title;
	}

	public String getGb_content() {
		return gb_content;
	}

	public void setGb_content(String gb_content) {
		this.gb_content = gb_content;
	}

	public int getGb_inven() {
		return gb_inven;
	}

	public void setGb_inven(int gb_inven) {
		this.gb_inven = gb_inven;
	}

	public String getGb_date() {
		return gb_date;
	}

	public void setGb_date(String gb_date) {
		this.gb_date = gb_date;
	}

	public String getMem_id() {
		return mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

	public String getMem_name() {
		return mem_name;
	}

	public void setMem_name(String mem_name) {
		this.mem_name = mem_name;
	}

	public String getMem_code() {
		return mem_code;
	}

	public void setMem_code(String mem_code) {
		this.mem_code = mem_code;
	}

	public String getMem_photo() {
		return mem_photo;
	}

	public void setMem_photo(String mem_photo) {
		this.mem_photo = mem_photo;
	}

}
