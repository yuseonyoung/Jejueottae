package kr.or.ddit.middle.vo;
//출석체크 VO
public class AttendanceVO {
	private String mem_id;
	private String att_date;
	
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getAtt_date() {
		return att_date;
	}
	public void setAtt_date(String att_date) {
		this.att_date = att_date;
	}
	
	

}
