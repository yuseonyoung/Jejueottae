package kr.or.ddit.middle.vo;

public class PhotoVO {

	private String pt_code;
	private String pt_ofile;
	private String pt_sfile;
	private String pt_type;
	private String pt_pacode;

	public PhotoVO() {
	}

	public String getPt_code() {
		return pt_code;
	}

	public void setPt_code(String pt_code) {
		this.pt_code = pt_code;
	}

	public String getPt_ofile() {
		return pt_ofile;
	}

	public void setPt_ofile(String pt_ofile) {
		this.pt_ofile = pt_ofile;
	}

	public String getPt_sfile() {
		return pt_sfile;
	}

	public void setPt_sfile(String pt_sfile) {
		this.pt_sfile = pt_sfile;
	}

	public String getPt_type() {
		return pt_type;
	}

	public void setPt_type(String pt_type) {
		this.pt_type = pt_type;
	}

	public String getPt_pacode() {
		return pt_pacode;
	}

	public void setPt_pacode(String pt_pacode) {
		this.pt_pacode = pt_pacode;
	}

}
