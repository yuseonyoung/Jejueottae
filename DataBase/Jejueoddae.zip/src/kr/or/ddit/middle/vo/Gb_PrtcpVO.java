package kr.or.ddit.middle.vo;

public class Gb_PrtcpVO {

	private String gb_code;
	private String mem_id;

	public Gb_PrtcpVO() {
	}

	public String getGb_code() {
		return gb_code;
	}

	public void setGb_code(String gb_code) {
		this.gb_code = gb_code;
	}

	public String getMem_id() {
		return mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

}
