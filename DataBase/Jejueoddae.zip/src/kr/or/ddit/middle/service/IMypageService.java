package kr.or.ddit.middle.service;

import java.util.List;

import kr.or.ddit.middle.vo.Info_CouponVO;
import kr.or.ddit.middle.vo.Info_ReservVO;
import kr.or.ddit.middle.vo.View_PhotoVO;
import kr.or.ddit.middle.vo.WishListVO;

public interface IMypageService {
	
	/**
	 * 
	 * 마이페이지-> wishList 조회 메서드 
	 * 
	 * 세션에 들어있는 id값을  매서드에 param으로 보내서  wishList 조회에 필요한 데이터를 View_PhotoVO에 담아서 출력해준다.
	 * 
	 * @param id : 세션에 저장되어있는 id값 
	 * @return 마이페이지의 wishLsit 조회에서 화면에 보여줄 숙박업체와 사진명 return
	 */
	public  List<View_PhotoVO> resListCheck(String id);
	
	/**
	 * 
	 * 마이페이지 -> 예약내역 조회 메서드
	 * 
	 * 세션에 들어있는 id값을 메서드에 param으로 보내서 예약내역 조회에 필요한 데이터를 Search_AccomVO에 담아서 출력해준다.
	 * 
	 * @param id : 세션에 저장되어 있는 id값
	 * @return : 예약내역 리스트 return (체크인날짜, 체크인시간, 숙소이름, 위치, 숙박기간, 예약상태)
	 */
	public List<Info_ReservVO> resInfoCheck(String id);
	
	/**
	 * 
	 * 마이페이지 -> 쿠폰조회 메서드
	 * 
	 * 세션에 들어있는 id값을 메서드에 param으로 보내서 존재하는 coupon을 Info_CouponVO에 담아서 출력해준다.
	 * 
	 * @param id : 세션에 저장되어 있는 id값
	 * @return 쿠폰정보 return
	 */
	public List<Info_CouponVO> couponCheck(String id);
	
	/**
	 * 
	 * 하트 버튼을 누르면 먼저 wishList에 해당 하트를 클릭한 a_code가 위시리스트에 존재하는지 조회해본다.
	 * 해당 메서드의 반환값이 0이 나오면 insert 1이나오면  delete를 실행하면된다.
	 * 
	 * @param vo : mem_id과 a_code-> 위시리스트 정보
	 * @return 1이면 성공, 0이면 실패 -> 1이면 delete , 0이면 insert
	 */
	public int wishListCheck(WishListVO vo);
	
	/**
	 * 위시리스트 삭제 메서드
	 * 
	 * 하트를 눌러 위시리스트를 조회했을때 해당 a_code(숙박업체코드)가 위시리스에 존재하면 해당 a_code의 위시리스트 삭제기능
	 * 
	 * @param vo : a_code와 mem_id
	 * @return 성공시 1, 실패시 0 반환
	 */
	public int wishListDelete(WishListVO vo);
	
	/**
	 * 
	 * 위시리스트 등록 메서드
	 * 
	 * 하트를 눌러 위시리스트를 조회했을때 해당 a_code(숙박업체코드)가 위시리스에 존재하지않으면 해당 a_code의 위시리스트 등록기능
	 * 
	 * @param vo :a_code와 mem_id
	 * @return 성공시 1, 실패시 0 반환
	 */
	public int wishListInsert(WishListVO vo);
}
