package kr.or.ddit.middle.service;

import java.util.List;

import kr.or.ddit.middle.dao.IMypageDao;
import kr.or.ddit.middle.dao.MypageDaoImpl;
import kr.or.ddit.middle.vo.Info_CouponVO;
import kr.or.ddit.middle.vo.Info_ReservVO;
import kr.or.ddit.middle.vo.View_PhotoVO;
import kr.or.ddit.middle.vo.WishListVO;

public class MyPageServiceImpl implements IMypageService {

	private static MyPageServiceImpl service;

	private MypageDaoImpl dao;

	private MyPageServiceImpl() {
		dao = MypageDaoImpl.getInstance();
	}

	public static MyPageServiceImpl getInstance() {
		if (service == null)
			service = new MyPageServiceImpl();
		return service;
	}

	@Override
	public List<View_PhotoVO> resListCheck(String id) {

		return dao.resListCheck(id);
	}

	@Override
	public List<Info_ReservVO> resInfoCheck(String id) {

		return dao.resInfoCheck(id);
	}

	@Override
	public List<Info_CouponVO> couponCheck(String id) {

		return dao.couponCheck(id);
	}

	@Override
	public int wishListCheck(WishListVO vo) {

		return dao.wishListCheck(vo);
	}

	@Override
	public int wishListDelete(WishListVO vo) {

		return dao.wishListDelete(vo);
	}

	@Override
	public int wishListInsert(WishListVO vo) {

		return dao.wishListInsert(vo);
	}


}
