package kr.or.ddit.middle.service;

import java.util.List;

import kr.or.ddit.middle.dao.AccommodationDaoImpl;
import kr.or.ddit.middle.vo.AccommodationVO;
import kr.or.ddit.middle.vo.Info_ReservVO;
import kr.or.ddit.middle.vo.Search_AccomVO;

public class AccommodationServiceImpl implements IAccommodationService {

	private static AccommodationServiceImpl service;

	private AccommodationDaoImpl dao;

	private AccommodationServiceImpl() {
		dao = AccommodationDaoImpl.getInstance();
	}

	public static IAccommodationService getInstance() {
		if (service == null)
			service = new AccommodationServiceImpl();
		return service;
	}

	@Override
	public String acMainPhoto(String id) {

		return dao.acMainPhoto(id);
	}

	@Override
	public List<String> acMultiplePhoto(String id) {

		return dao.acMultiplePhoto(id);
	}

	@Override
	public List<Info_ReservVO> resDetailCheck(String id) {

		return dao.resDetailCheck(id);
	}

	@Override
	public List<Search_AccomVO> acSearch(Search_AccomVO vo) {

		return dao.acSearch(vo);
	}

	@Override
	public List<Search_AccomVO> acSearchFilter(Search_AccomVO vo) {

		return dao.acSearchFilter(vo);
	}

	@Override
	public List<AccommodationVO> acCheck(String type) {

		return dao.acCheck(type);
	}

	@Override
	public List<Search_AccomVO> acCheckFilter(String type) {

		return dao.acCheckFilter(type);
	}

	@Override
	public List<String> filterList(List<String> list) {

		return dao.filterList(list);
	}

}
