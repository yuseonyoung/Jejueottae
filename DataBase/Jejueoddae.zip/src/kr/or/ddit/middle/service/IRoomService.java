package kr.or.ddit.middle.service;

import kr.or.ddit.middle.vo.RoomVO;

public interface IRoomService {
	/**
	 * 
	 * Room insert 메서드
	 *  
	 * @param vo : Room의 테이터값을 param으로 받아와서 값을 insert한다.
	 * @return 성공시 1, 실패시 0
	 */
	public int roomInsert(RoomVO vo);

	public List<>
}
