package kr.or.ddit.middle.dao;

import java.util.List;

import kr.or.ddit.middle.vo.Info_CouponVO;
import kr.or.ddit.middle.vo.Info_ReservVO;
import kr.or.ddit.middle.vo.View_PhotoVO;
import kr.or.ddit.middle.vo.WishListVO;

public class MypageDaoImpl implements IMypageDao {

	private static MypageDaoImpl dao;

	private MypageDaoImpl() {
	}

	public static MypageDaoImpl getInstance() {
		if (dao == null)
			dao = new MypageDaoImpl();
		return dao;
	}

	@Override
	public List<View_PhotoVO> resListCheck(String id) {

		return null;
	}

	@Override
	public List<Info_ReservVO> resInfoCheck(String id) {

		return null;
	}

	@Override
	public List<Info_CouponVO> couponCheck(String id) {

		return null;
	}

	@Override
	public int wishListCheck(WishListVO vo) {

		return 0;
	}

	@Override
	public int wishListDelete(WishListVO vo) {

		return 0;
	}

	@Override
	public int wishListInsert(WishListVO vo) {

		return 0;
	}
}
