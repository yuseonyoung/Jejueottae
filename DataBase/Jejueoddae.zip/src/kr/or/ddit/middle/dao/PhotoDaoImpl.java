package kr.or.ddit.middle.dao;

import kr.or.ddit.middle.vo.PhotoVO;

public class PhotoDaoImpl implements IPhotoDao {

	private static PhotoDaoImpl dao;

	private PhotoDaoImpl() {
	}

	public static PhotoDaoImpl getInstance() {
		if (dao == null)
			dao = new PhotoDaoImpl();
		return dao;
	}

	@Override
	public int photoInsert(PhotoVO vo) {

		return 0;
	}

}
