package kr.or.ddit.middle.dao;

import java.util.List;

import kr.or.ddit.middle.vo.AccommodationVO;
import kr.or.ddit.middle.vo.Info_ReservVO;
import kr.or.ddit.middle.vo.Search_AccomVO;

public class AccommodationDaoImpl implements IAccommodationDao {

	private static AccommodationDaoImpl dao;

	private AccommodationDaoImpl() {
	}

	public static AccommodationDaoImpl getInstance() {
		if (dao == null)
			dao = new AccommodationDaoImpl();
		return dao;
	}

	@Override
	public String acMainPhoto(String id) {

		return null;
	}

	@Override
	public List<String> acMultiplePhoto(String id) {

		return null;
	}

	@Override
	public List<Info_ReservVO> resDetailCheck(String id) {

		return null;
	}

	@Override
	public List<Search_AccomVO> acSearch(Search_AccomVO vo) {

		return null;
	}

	@Override
	public List<Search_AccomVO> acSearchFilter(Search_AccomVO vo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<AccommodationVO> acCheck(String type) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Search_AccomVO> acCheckFilter(String type) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> filterList(List<String> list) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
