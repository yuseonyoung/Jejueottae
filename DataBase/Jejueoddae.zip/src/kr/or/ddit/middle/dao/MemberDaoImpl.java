package kr.or.ddit.middle.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.or.ddit.middle.vo.MemberVO;
import kr.or.ddit.mybatis.config.MyBatisUtil;

public class MemberDaoImpl implements IMemberDao {

	private static MemberDaoImpl dao;

	private MemberDaoImpl() {
	}

	public static MemberDaoImpl getInstance() {
		if (dao == null)
			dao = new MemberDaoImpl();
		return dao;
	}

	@Override
	public int checkInfo(MemberVO vo) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = MyBatisUtil.getSqlSession();
			
			
		} catch (Exception e) {
			
		}
		return cnt;
	}

	@Override
	public String findId(String email) {

		return null;
	}

	@Override
	public int findPass(MemberVO vo) {

		return 0;
	}

	@Override
	public int updatePass(String id) {

		return 0;
	}

	@Override
	public int joinMember(MemberVO vo) {

		return 0;
	}

	@Override
	public int checkDuple(String id) {

		return 0;
	}

	@Override
	public List<MemberVO> memberInfo(String id) {

		return null;
	}

	@Override
	public int memberInfoUpdate(MemberVO vo) {

		return 0;
	}

	@Override
	public int memberPhotoUpload(MemberVO vo) {

		return 0;
	}

}
